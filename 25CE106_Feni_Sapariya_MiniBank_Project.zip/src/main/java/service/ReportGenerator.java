package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ReportGenerator walks transaction logs, aggregates deposits and withdrawals using NIO.2,
 * reads file attributes, and produces structured audit reports.
 * Semester 3 Object-Oriented Programming (CEUE203) - Practical 11
 */
public final class ReportGenerator {

    private static final Pattern TRANSACTION_PATTERN =
            Pattern.compile(".*(DEPOSIT|WITHDRAW|TRANSFER)\\s+(?:AC\\d+\\s+)?₹?(\\d+).*", Pattern.CASE_INSENSITIVE);

    private ReportGenerator() {
        // Private constructor for utility class
    }

    /**
     * Walks log files using NIO.2 DirectoryStream, aggregates transaction totals, and writes an audit summary.
     *
     * @param logsDir    directory containing .log files
     * @param outputFile path to save the generated report (or null to only return the string)
     * @return structured report string
     * @throws IOException if reading or writing files fails
     */
    public static String generateSummary(Path logsDir, Path outputFile) throws IOException {
        if (!Files.exists(logsDir) || !Files.isDirectory(logsDir)) {
            return "No log directory found at: " + logsDir;
        }

        long totalDeposits = 0;
        long totalWithdrawals = 0;
        int transactionCount = 0;
        int filesProcessed = 0;

        StringBuilder reportBuilder = new StringBuilder();
        reportBuilder.append("=====================================================\n");
        reportBuilder.append("               MINIBANK AUDIT REPORT                 \n");
        reportBuilder.append("=====================================================\n\n");

        // DirectoryStream provides lazy iteration over files without loading all descriptors into memory
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(logsDir, "*.log")) {
            for (Path logFile : stream) {
                filesProcessed++;
                BasicFileAttributes attributes = Files.readAttributes(logFile, BasicFileAttributes.class);
                reportBuilder.append(String.format("File: %s | Size: %d bytes | Modified: %s\n",
                        logFile.getFileName(), attributes.size(), attributes.lastModifiedTime()));

                try (BufferedReader reader = Files.newBufferedReader(logFile)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        Matcher matcher = TRANSACTION_PATTERN.matcher(line);
                        if (matcher.matches()) {
                            transactionCount++;
                            String type = matcher.group(1).toUpperCase();
                            long amount = Long.parseLong(matcher.group(2));
                            if ("DEPOSIT".equals(type)) {
                                totalDeposits += amount;
                            } else {
                                totalWithdrawals += amount;
                            }
                        }
                    }
                }
            }
        }

        reportBuilder.append("\n-----------------------------------------------------\n");
        reportBuilder.append(String.format("Log Files Scanned   : %d\n", filesProcessed));
        reportBuilder.append(String.format("Total Transactions  : %d\n", transactionCount));
        reportBuilder.append(String.format("Total Deposited     : ₹%,d\n", totalDeposits));
        reportBuilder.append(String.format("Total Withdrawn     : ₹%,d\n", totalWithdrawals));
        reportBuilder.append(String.format("Net Flow            : ₹%,d\n", totalDeposits - totalWithdrawals));
        reportBuilder.append("=====================================================\n");

        String report = reportBuilder.toString();

        if (outputFile != null) {
            if (outputFile.getParent() != null) {
                Files.createDirectories(outputFile.getParent());
            }
            try (BufferedWriter writer = Files.newBufferedWriter(outputFile)) {
                writer.write(report);
            }
        }

        return report;
    }
}

package util;

import model.Account;

/**
 * StatementFormatter generates clean, multi-line account statements using StringBuilder.
 * Semester 3 Object-Oriented Programming (CEUE203) - Practical 04 & 06
 */
public class StatementFormatter {

    /**
     * Assembles a formatted multi-line account statement using a StringBuilder for efficiency.
     *
     * @param account the target account to format
     * @return structured string representation of the account statement
     */
    public static String buildStatement(Account account) {
        if (account == null) {
            return "No account specified for statement.";
        }

        // Using StringBuilder avoids creating unnecessary intermediate String objects
        StringBuilder statementBuilder = new StringBuilder();
        statementBuilder.append("====================================================\n");
        statementBuilder.append("            MINIBANK ACCOUNT STATEMENT              \n");
        statementBuilder.append("====================================================\n");
        statementBuilder.append(String.format(" Account Number : %s%n", account.getAccountNumber()));
        statementBuilder.append(String.format(" Account Holder : %s%n", account.getOwnerName()));
        statementBuilder.append(String.format(" Account Type   : %s%n", account.getClass().getSimpleName()));
        statementBuilder.append(String.format(" Interest Rate  : %.1f%%%n", account.interestRate()));
        statementBuilder.append(String.format(" Current Balance: ₹%d%n", account.getBalance()));
        statementBuilder.append(String.format(" Status         : %s%n", account.isActive() ? "ACTIVE" : "INACTIVE"));
        statementBuilder.append("----------------------------------------------------\n");
        statementBuilder.append(" Statement generated successfully via StringBuilder.\n");
        statementBuilder.append("====================================================\n");

        return statementBuilder.toString();
    }
}
